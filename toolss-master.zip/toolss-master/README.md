# Tools

Automatic hacking tools installer for Android [ONLY FOR TERMUX]


YouTube Channel: https://www.youtube.com/user/kalinuxx


Facebook: https://www.facebook.com/kalinuxtutorials/

# Installation
Watch Video: https://www.youtube.com/watch?v=8KvY2NM47ZM
```
git clone https://github.com/AnonHackerr/toolss.git
cd toolss
chmod +x Tools.py
python Tools.py
```
# Screenshot
<img src="https://i.imgur.com/OhhVPzU.png"/>
